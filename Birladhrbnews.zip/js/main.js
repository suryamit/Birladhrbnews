document.addEventListener("DOMContentLoaded", () => {
  const dateElem = document.getElementById("current-date");
  if (dateElem) {
    const now = new Date();
    dateElem.textContent = `Today's Date: ${now.toDateString()}`;
  }
  loadArticles();
});

let articleIndex = 0;
const articlesPerPage = 3;

async function loadArticles() {
  const res = await fetch("data/articles.json");
  const data = await res.json();
  const container = document.getElementById("article-list");

  for (let i = articleIndex; i < articleIndex + articlesPerPage && i < data.length; i++) {
    const article = document.createElement("div");
    article.className = "card";
    article.innerHTML = `<h3>${data[i].title}</h3><p>${data[i].content}</p>`;
    container.appendChild(article);
  }

  articleIndex += articlesPerPage;
}

function loadMoreArticles() {
  loadArticles();
}
